package com.example.riverpod_bottom_navigation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
